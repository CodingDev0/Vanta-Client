# Build notes

This revision uses a conservative Android toolchain:

- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Gradle 8.9
- Java 17
- compileSdk 35
- Compose BOM 2024.12.01

The previous dependency declaration mixed a Compose BOM with an explicit Material 3 version. The corrected project lets the BOM control Compose library versions.
