package com.vanta.client

import android.app.GameManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Display
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import java.io.File
import kotlin.math.roundToInt

private val Black = Color(0xFF050505)
private val Panel = Color(0xFF0E0E0E)
private val Panel2 = Color(0xFF151515)
private val White = Color(0xFFF4F4F4)
private val Muted = Color(0xFF8E8E8E)
private val Line = Color(0xFF292929)

class MainActivity : ComponentActivity() {
    private lateinit var store: ProfileStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProfileStore(this)
        setMaximumRefreshPreference()
        setContent { VantaTheme { VantaRoot(this, store) } }
    }

    private fun setMaximumRefreshPreference() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val maximum = DeviceInfo.refresh(this)
            window.attributes = window.attributes.apply {
                preferredRefreshRate = maximum
            }
        }
    }

    fun launchMinecraft() {
        packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")?.let {
            startActivity(it)
        } ?: startActivity(
            Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:com.mojang.minecraftpe"),
            ),
        )
    }

    fun openOverlayPermission() {
        startActivity(
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"),
            ),
        )
    }

    fun requestPerformanceMode() {
        android.widget.Toast.makeText(
            this,
            "Use tools/minecraft-performance-adb to request Performance Mode for Minecraft.",
            android.widget.Toast.LENGTH_LONG,
        ).show()
    }

    fun importFile(uri: Uri): File? {
        val name = contentResolver.query(
            uri,
            arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),
            null, null, null,
        )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            ?: "vanta-import-${System.currentTimeMillis()}"

        val target = File(filesDir, "imports/${
            name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        }")
        target.parentFile?.mkdirs()
        return runCatching {
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input)
                target.outputStream().use(input::copyTo)
            }
            target
        }.getOrNull()
    }

    fun openImportedFile(file: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            launchMinecraft()
        }
    }
}

@Composable
private fun VantaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = androidx.compose.material3.darkColorScheme(
            primary = White,
            onPrimary = Black,
            background = Black,
            surface = Panel,
            onSurface = White,
            secondary = Muted,
            outline = Line,
        ),
        content = content,
    )
}

@Composable
private fun VantaRoot(activity: MainActivity, store: ProfileStore) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var settings by remember { mutableStateOf(store.load()) }
    var files by remember { mutableStateOf(emptyList<File>()) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) activity.importFile(uri)?.let {
            files = (files + it).distinctBy(File::getName)
        }
    }

    val tabs = listOf(
        Icons.Default.Home to "Home",
        Icons.Default.Speed to "Boost",
        Icons.Default.GridView to "HUD",
        Icons.Default.Extension to "Packs",
        Icons.Default.Settings to "More",
    )

    androidx.compose.material3.Scaffold(
        containerColor = Black,
        bottomBar = {
            NavigationBar(
                modifier = Modifier.navigationBarsPadding(),
                containerColor = Panel,
            ) {
                tabs.forEachIndexed { index, (icon, label) ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = { Icon(icon, label) },
                        label = { Text(label) },
                    )
                }
            }
        },
    ) { padding ->
        when (tab) {
            0 -> HomePage(
                Modifier.padding(padding),
                settings,
                activity,
                onProfile = { profile ->
                    settings = settings.copy(profile = profile)
                    store.save(settings)
                },
            )
            1 -> PerformancePage(
                Modifier.padding(padding),
                settings,
                activity,
                onSettings = { next ->
                    settings = next
                    store.save(next)
                },
            )
            2 -> HudPage(
                Modifier.padding(padding),
                settings,
                activity,
                onSettings = { next ->
                    settings = next
                    store.save(next)
                },
            )
            3 -> PacksPage(
                Modifier.padding(padding),
                files,
                { picker.launch(arrayOf("application/octet-stream", "application/zip", "*/*")) },
                activity::openImportedFile,
            )
            else -> MorePage(
                Modifier.padding(padding),
                settings,
                activity,
                onSettings = { next ->
                    settings = next
                    store.save(next)
                },
                onExport = {
                    val file = store.exportJson()
                    activity.openImportedFile(file)
                },
            )
        }
    }
}

@Composable
private fun HomePage(
    modifier: Modifier,
    settings: VantaSettings,
    activity: MainActivity,
    onProfile: (VantaProfile) -> Unit,
) {
    LazyColumn(
        modifier.fillMaxSize().background(Black).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("VANTA", color = White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
                    Text("BEDROCK CLIENT", color = Muted, fontWeight = FontWeight.Bold)
                }
                Surface(color = Panel2, shape = RoundedCornerShape(12.dp)) {
                    Text("2.0", color = White, modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(22.dp)) {
                    Text("VANTA", color = White, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Black)
                    Text("THE MONOCHROME BEDROCK COMPANION", color = Muted, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(14.dp))
                    Text(DeviceInfo.deviceSummary(activity), color = Muted)
                    Spacer(Modifier.height(18.dp))
                    Button(onClick = activity::launchMinecraft, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.SportsEsports, null)
                        Spacer(Modifier.width(8.dp))
                        Text("LAUNCH BEDROCK")
                    }
                }
            }
        }
        item { SectionLabel("SMART PROFILES") }
        items(VantaProfile.entries) { profile ->
            ProfileCard(profile, profile == settings.profile) { onProfile(profile) }
        }
        item {
            InfoCard(
                "VANTA RULE",
                "Vanta never fakes FPS. Performance profiles prepare the device and client settings, but Minecraft's private renderer remains controlled by Minecraft.",
            )
        }
    }
}

@Composable
private fun ProfileCard(profile: VantaProfile, selected: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = if (selected) Panel2 else Panel),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                when (profile) {
                    VantaProfile.PERFORMANCE -> Icons.Default.Bolt
                    VantaProfile.PVP -> Icons.Default.SportsEsports
                    VantaProfile.BALANCED -> Icons.Default.Tune
                    VantaProfile.BATTERY -> Icons.Default.BatteryChargingFull
                    VantaProfile.CUSTOM -> Icons.Default.Settings
                },
                null,
                tint = White,
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(profile.label, color = White, fontWeight = FontWeight.Bold)
                Text(
                    "${profile.fpsTarget} FPS target • ${profile.renderDistance} chunks • HUD ${if (profile.hud) "ON" else "OFF"}",
                    color = Muted,
                )
            }
            if (selected) Text("ACTIVE", color = White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PerformancePage(
    modifier: Modifier,
    settings: VantaSettings,
    activity: MainActivity,
    onSettings: (VantaSettings) -> Unit,
) {
    val telemetry = remember { DeviceInfo.telemetry(activity) }
    LazyColumn(
        modifier.fillMaxSize().background(Black).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item { ScreenTitle("BOOST", "Device-aware performance controls.") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                MiniStat("REFRESH", "${telemetry.refreshHz} Hz", Modifier.weight(1f))
                MiniStat("GAME MODE", telemetry.gameMode, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                MiniStat("RAM", "${"%.1f".format(telemetry.ramAvailableGb)} GB FREE", Modifier.weight(1f))
                MiniStat("THERMAL", telemetry.thermal, Modifier.weight(1f))
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(18.dp)) {
                    Text("FPS TARGET PROFILE", color = White, fontWeight = FontWeight.Bold)
                    Text("${settings.profile.fpsTarget} FPS", color = Muted)
                    Text(
                        "Profile target only; no false renderer unlock claim.",
                        color = Muted,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                }
            }
        }
        item {
            InfoCard(
                "THERMAL GUARD",
                "If Android reports severe or critical thermal status, use Balanced/Battery instead of forcing sustained performance.",
            )
        }
        item {
            OutlinedButton(
                onClick = activity::requestPerformanceMode,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Icon(Icons.Default.Bolt, null)
                Spacer(Modifier.width(8.dp))
                Text("REQUEST PERFORMANCE MODE")
            }
        }
        item {
            SettingSwitch("Safe performance", settings.safeMode) {
                onSettings(settings.copy(safeMode = it))
            }
        }
    }
}

@Composable
private fun HudPage(
    modifier: Modifier,
    settings: VantaSettings,
    activity: MainActivity,
    onSettings: (VantaSettings) -> Unit,
) {
    LazyColumn(
        modifier.fillMaxSize().background(Black).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { ScreenTitle("HUD LAB", "Build your PvP/performance overlay.") }
        item {
            SettingSwitch("HUD enabled", settings.profile.hud, null) {
                onSettings(settings.copy(profile = settings.profile.copy(hud = it)))
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(18.dp)) {
                    Text("HUD SCALE", color = White, fontWeight = FontWeight.Bold)
                    Text("${(settings.hudScale * 100).roundToInt()}%", color = Muted)
                    Slider(
                        value = settings.hudScale,
                        onValueChange = { onSettings(settings.copy(hudScale = it)) },
                        valueRange = 0.75f..1.5f,
                    )
                    Text("OPACITY ${settings.hudOpacity.times(100).roundToInt()}%", color = Muted)
                    Slider(
                        value = settings.hudOpacity,
                        onValueChange = { onSettings(settings.copy(hudOpacity = it)) },
                    )
                }
            }
        }
        item { SettingSwitch("FPS", settings.showFps) { onSettings(settings.copy(showFps = it)) } }
        item { SettingSwitch("Refresh rate", settings.showRefresh) { onSettings(settings.copy(showRefresh = it)) } }
        item { SettingSwitch("Coordinates", settings.showCoordinates) { onSettings(settings.copy(showCoordinates = it)) } }
        item { SettingSwitch("CPS", settings.showCps) { onSettings(settings.copy(showCps = it)) } }
        item { SettingSwitch("Keystrokes", settings.showKeystrokes) { onSettings(settings.copy(showKeystrokes = it)) } }
        item { SettingSwitch("Ping", settings.showPing) { onSettings(settings.copy(showPing = it)) } }
        item { SettingSwitch("Session timer", settings.showSession) { onSettings(settings.copy(showSession = it)) } }
        item { SettingSwitch("Snap to grid", settings.snapGrid) { onSettings(settings.copy(snapGrid = it)) } }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(18.dp)) {
                    Text("HUD PRESET", color = White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "VANTA  •  ${if (settings.showFps) "FPS" else ""}  ${if (settings.showRefresh) "REFRESH" else ""}  ${if (settings.showCps) "CPS" else ""}",
                        color = White,
                    )
                    Text("Monochrome • snap ${if (settings.snapGrid) "ON" else "OFF"}", color = Muted)
                }
            }
        }
    }
}

@Composable
private fun PacksPage(
    modifier: Modifier,
    files: List<File>,
    onImport: () -> Unit,
    onOpen: (File) -> Unit,
) {
    Column(modifier.fillMaxSize().background(Black).padding(20.dp)) {
        ScreenTitle("PACKS", "Import, store and launch Bedrock content.")
        OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Add, null)
            Spacer(Modifier.width(8.dp))
            Text("IMPORT .MCPACK / .MCADDON")
        }
        Spacer(Modifier.height(12.dp))
        if (files.isEmpty()) {
            InfoCard("PACK LIBRARY", "No packs imported yet.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(files, key = File::getAbsolutePath) { file ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onOpen(file) },
                        colors = CardDefaults.cardColors(containerColor = Panel),
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Extension, null, tint = White)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(file.name, color = White, fontWeight = FontWeight.Bold)
                                Text("Tap to hand off to Android/Minecraft", color = Muted)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MorePage(
    modifier: Modifier,
    settings: VantaSettings,
    activity: MainActivity,
    onSettings: (VantaSettings) -> Unit,
    onExport: () -> Unit,
) {
    LazyColumn(
        modifier.fillMaxSize().background(Black).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { ScreenTitle("MORE", "Profiles, safety and portable configuration.") }
        item {
            SettingCard("Safe Mode", "Disable risky overlay behavior.", Icons.Default.Build) {
                Switch(settings.safeMode, { onSettings(settings.copy(safeMode = it)) })
            }
        }
        item {
            SettingCard("HUD overlay", "Android overlay permission.", Icons.Default.Layers) {
                OutlinedButton(onClick = activity::openOverlayPermission) { Text("MANAGE") }
            }
        }
        item {
            SettingCard("Export profile", "Save Vanta settings as JSON.", Icons.Default.Save) {
                Button(onClick = onExport) { Text("EXPORT") }
            }
        }
        item {
            SettingCard("Device", DeviceInfo.deviceSummary(activity), Icons.Default.Memory) {
                Text("READY", color = Muted)
            }
        }
        item {
            InfoCard(
                "FINAL RECOMMENDATION",
                "Use Performance for high-refresh play, PvP for lower render distance and a denser HUD, Balanced for everyday play, and Battery when thermal/battery life matters. Custom is the manual sandbox.",
            )
        }
        item {
            InfoCard(
                "WHAT VANTA DOES NOT DO",
                "It does not inject into Minecraft, modify Mojang's APK, bypass paid content, or fabricate FPS. That keeps the client maintainable and honest.",
            )
        }
    }
}

@Composable
private fun ScreenTitle(title: String, subtitle: String) {
    Column {
        Spacer(Modifier.height(10.dp))
        Text(title, color = White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
        Text(subtitle, color = Muted)
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, color = Muted, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
}

@Composable
private fun SettingSwitch(
    title: String,
    checked: Boolean,
    modifier: Modifier? = null,
    onChange: (Boolean) -> Unit,
) {
    Card(
        modifier = (modifier ?: Modifier).fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Panel),
    ) {
        Row(
            Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(title, color = White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }
}

@Composable
private fun MiniStat(title: String, value: String, modifier: Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = Muted, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(4.dp))
            Text(value, color = White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SettingCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    action: @Composable () -> Unit,
) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = White)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = White, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Muted)
            }
            action()
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, null, tint = White)
                Spacer(Modifier.width(8.dp))
                Text(title, color = White, fontWeight = FontWeight.Bold)
            }
            HorizontalDivider(Modifier.padding(vertical = 10.dp), color = Line)
            Text(body, color = Muted)
        }
    }
}
