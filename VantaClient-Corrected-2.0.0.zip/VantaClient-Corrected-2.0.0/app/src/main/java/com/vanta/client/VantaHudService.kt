package com.vanta.client

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.roundToInt

class VantaHudService : Service() {
    private var manager: WindowManager? = null
    private var view: TextView? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(5001, notification())
        if (Settings.canDrawOverlays(this)) showHud() else stopSelf()
    }

    override fun onDestroy() {
        view?.let { manager?.removeView(it) }
        view = null
        manager = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun showHud() {
        val text = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(210, 5, 5, 5))
            textSize = 12f
            setPadding(14, 8, 14, 8)
            text = "VANTA  •  ${DeviceInfo.refresh(this@VantaHudService).roundToInt()} Hz  •  ${DeviceInfo.gameMode(this@VantaHudService)}"
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 18
            y = 58
        }

        manager = getSystemService(WindowManager::class.java)
        manager?.addView(text, params)
        view = text
    }

    private fun createChannel() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(
                NotificationChannel(
                    "vanta_hud",
                    "Vanta HUD",
                    NotificationManager.IMPORTANCE_LOW,
                ),
            )
    }

    private fun notification(): Notification =
        Notification.Builder(this, "vanta_hud")
            .setContentTitle("Vanta HUD")
            .setContentText("Performance telemetry overlay active")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .build()

    companion object {
        fun start(context: Context) {
            if (!Settings.canDrawOverlays(context)) return
            val intent = Intent(context, VantaHudService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, VantaHudService::class.java))
        }
    }
}
