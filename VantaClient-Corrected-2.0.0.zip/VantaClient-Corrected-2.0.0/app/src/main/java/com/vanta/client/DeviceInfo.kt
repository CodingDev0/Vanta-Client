package com.vanta.client

import android.app.ActivityManager
import android.app.GameManager
import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.view.Display
import android.view.WindowManager
import java.util.Locale
import kotlin.math.roundToInt

data class DeviceTelemetry(
    val refreshHz: Int,
    val gameMode: String,
    val ramTotalGb: Double,
    val ramAvailableGb: Double,
    val battery: Int,
    val thermal: String,
    val cpuCores: Int,
)

object DeviceInfo {
    fun refresh(context: Context): Float =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            context.getSystemService(WindowManager::class.java)
                .defaultDisplay.supportedModes
                .maxByOrNull(Display.Mode::getRefreshRate)
                ?.refreshRate ?: 60f
        } else 60f

    fun gameMode(context: Context): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return "UNAVAILABLE"
        val mode = context.getSystemService(GameManager::class.java)?.gameMode
            ?: return "UNAVAILABLE"
        return when (mode) {
            GameManager.GAME_MODE_PERFORMANCE -> "PERFORMANCE"
            GameManager.GAME_MODE_BATTERY -> "BATTERY"
            GameManager.GAME_MODE_CUSTOM -> "CUSTOM"
            GameManager.GAME_MODE_STANDARD -> "STANDARD"
            else -> "UNSUPPORTED"
        }
    }

    fun telemetry(context: Context): DeviceTelemetry {
        val activityManager = context.getSystemService(ActivityManager::class.java)
        val memory = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memory)

        val batteryManager = context.getSystemService(BatteryManager::class.java)
        val battery = batteryManager.getIntProperty(
            BatteryManager.BATTERY_PROPERTY_CAPACITY,
        ).coerceIn(0, 100)

        val power = context.getSystemService(PowerManager::class.java)
        val thermal = when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ->
                when (power.currentThermalStatus) {
                    PowerManager.THERMAL_STATUS_NONE -> "COOL"
                    PowerManager.THERMAL_STATUS_LIGHT -> "LIGHT"
                    PowerManager.THERMAL_STATUS_MODERATE -> "MODERATE"
                    PowerManager.THERMAL_STATUS_SEVERE -> "SEVERE"
                    PowerManager.THERMAL_STATUS_CRITICAL -> "CRITICAL"
                    PowerManager.THERMAL_STATUS_EMERGENCY -> "EMERGENCY"
                    PowerManager.THERMAL_STATUS_SHUTDOWN -> "SHUTDOWN"
                    else -> "UNKNOWN"
                }
            else -> "UNAVAILABLE"
        }

        return DeviceTelemetry(
            refreshHz = refresh(context).roundToInt(),
            gameMode = gameMode(context),
            ramTotalGb = memory.totalMem / 1_073_741_824.0,
            ramAvailableGb = memory.availMem / 1_073_741_824.0,
            battery = battery,
            thermal = thermal,
            cpuCores = Runtime.getRuntime().availableProcessors(),
        )
    }

    fun deviceSummary(context: Context): String {
        val t = telemetry(context)
        return String.format(
            Locale.US,
            "%d Hz • %d cores • %.1f GB RAM • %d%% battery",
            t.refreshHz, t.cpuCores, t.ramTotalGb, t.battery,
        )
    }
}
