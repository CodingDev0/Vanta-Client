package com.vanta.client

import android.content.Context
import org.json.JSONObject
import java.io.File

enum class VantaProfile(
    val label: String,
    val fpsTarget: Int,
    val renderDistance: Int,
    val hud: Boolean,
) {
    PERFORMANCE("Performance", 120, 8, true),
    PVP("PvP", 120, 6, true),
    BALANCED("Balanced", 90, 10, true),
    BATTERY("Battery", 60, 6, false),
    CUSTOM("Custom", 120, 8, true),
}

data class VantaSettings(
    val profile: VantaProfile = VantaProfile.PERFORMANCE,
    val hudScale: Float = 1f,
    val hudOpacity: Float = 0.82f,
    val showFps: Boolean = true,
    val showRefresh: Boolean = true,
    val showCoordinates: Boolean = true,
    val showCps: Boolean = true,
    val showKeystrokes: Boolean = true,
    val showPing: Boolean = true,
    val showSession: Boolean = true,
    val snapGrid: Boolean = true,
    val safeMode: Boolean = false,
    val theme: String = "VANTA_MONO",
)

class ProfileStore(private val context: Context) {
    private val file: File
        get() = File(context.filesDir, "profiles/vanta.json")

    fun save(settings: VantaSettings) {
        file.parentFile?.mkdirs()
        val json = JSONObject().apply {
            put("profile", settings.profile.name)
            put("hudScale", settings.hudScale)
            put("hudOpacity", settings.hudOpacity)
            put("showFps", settings.showFps)
            put("showRefresh", settings.showRefresh)
            put("showCoordinates", settings.showCoordinates)
            put("showCps", settings.showCps)
            put("showKeystrokes", settings.showKeystrokes)
            put("showPing", settings.showPing)
            put("showSession", settings.showSession)
            put("snapGrid", settings.snapGrid)
            put("safeMode", settings.safeMode)
            put("theme", settings.theme)
        }
        file.writeText(json.toString(2))
    }

    fun load(): VantaSettings {
        if (!file.exists()) return VantaSettings()
        return runCatching {
            val json = JSONObject(file.readText())
            VantaSettings(
                profile = VantaProfile.valueOf(
                    json.optString("profile", VantaProfile.PERFORMANCE.name),
                ),
                hudScale = json.optDouble("hudScale", 1.0).toFloat(),
                hudOpacity = json.optDouble("hudOpacity", 0.82).toFloat(),
                showFps = json.optBoolean("showFps", true),
                showRefresh = json.optBoolean("showRefresh", true),
                showCoordinates = json.optBoolean("showCoordinates", true),
                showCps = json.optBoolean("showCps", true),
                showKeystrokes = json.optBoolean("showKeystrokes", true),
                showPing = json.optBoolean("showPing", true),
                showSession = json.optBoolean("showSession", true),
                snapGrid = json.optBoolean("snapGrid", true),
                safeMode = json.optBoolean("safeMode", false),
                theme = json.optString("theme", "VANTA_MONO"),
            )
        }.getOrDefault(VantaSettings())
    }

    fun exportJson(): File {
        if (!file.exists()) save(load())
        return file
    }

    fun importJson(source: File): VantaSettings {
        file.parentFile?.mkdirs()
        source.copyTo(file, overwrite = true)
        return load()
    }
}
