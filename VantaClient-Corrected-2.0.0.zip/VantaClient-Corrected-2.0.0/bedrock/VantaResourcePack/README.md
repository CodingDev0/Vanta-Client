# Vanta Bedrock Resource Pack

This pack is the supported Bedrock visual-layer foundation for Vanta.

It does not patch or inject into Minecraft. Add supported resource-pack/UI assets here as the target Bedrock version exposes them.
