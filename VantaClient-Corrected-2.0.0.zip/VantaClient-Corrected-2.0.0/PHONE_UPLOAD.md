# Phone upload

Upload this ZIP as a complete project archive to a cloud build service, or extract it before uploading to GitHub.

The repository root must contain `app/`, `.github/`, `build.gradle.kts`, and `settings.gradle.kts`.

Do not upload only the files inside `app/src`; the directory structure is required.
