@echo off
set PACKAGE=com.mojang.minecraftpe
adb shell pm path %PACKAGE%
if errorlevel 1 (
  echo Minecraft Bedrock was not found.
  exit /b 1
)
adb shell cmd game mode performance %PACKAGE%
echo Requested Android Performance Game Mode for Minecraft Bedrock.
echo This is an OS/OEM performance request, not a renderer FPS-cap bypass.
pause
