#!/usr/bin/env bash
set -euo pipefail
PACKAGE="com.mojang.minecraftpe"
adb shell pm path "$PACKAGE" >/dev/null
adb shell cmd game mode performance "$PACKAGE"
echo "Requested Android Performance Game Mode for Minecraft Bedrock."
echo "This is an OS/OEM performance request, not a renderer FPS-cap bypass."
