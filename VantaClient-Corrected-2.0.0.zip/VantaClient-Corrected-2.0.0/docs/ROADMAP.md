# Vanta roadmap

## Final 2.0 foundation
- Smart profiles
- PvP HUD architecture
- Performance monitor
- Pack manager
- Theme engine
- HUD editor
- Safe mode
- JSON portable profiles
- Fast launch
- Bedrock resource-pack foundation

## Future supported extensions
- More Bedrock UI modules as supported APIs expose them.
- Device-specific profile recommendations.
- More HUD layouts.
- More pack metadata and import validation.
